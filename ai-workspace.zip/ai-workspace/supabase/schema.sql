-- Supabase Dashboard > SQL Editor mein poora paste karke Run karein.

create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  credits int not null default 20 check (credits >= 0),
  created_at timestamptz not null default now()
);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  title text not null,
  created_at timestamptz not null default now()
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations on delete cascade,
  user_id uuid not null references auth.users on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  kind text not null default 'text' check (kind in ('text', 'image')),
  category text,
  content text not null,
  created_at timestamptz not null default now()
);

create index on public.conversations (user_id, created_at desc);
create index on public.messages (conversation_id, created_at);

-- Row Level Security: har user sirf apna data dekh sakta hai.
-- Likhna (insert/update) sirf server (service role) karta hai.
alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;

create policy "own profile" on public.profiles for select using (auth.uid() = id);
create policy "own conversations" on public.conversations for select using (auth.uid() = user_id);
create policy "delete own conversations" on public.conversations for delete using (auth.uid() = user_id);
create policy "own messages" on public.messages for select using (auth.uid() = user_id);

-- Naye user ko 20 free credits ke saath profile mil jaye.
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id) values (new.id);
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Atomic credit kaatna: credits kam hon to NULL wapas aata hai.
create function public.consume_credits(uid uuid, cost int) returns int
language plpgsql security definer set search_path = public as $$
declare remaining int;
begin
  update public.profiles set credits = credits - cost
  where id = uid and credits >= cost
  returning credits into remaining;
  return remaining;
end $$;

create function public.refund_credits(uid uuid, amount int) returns int
language plpgsql security definer set search_path = public as $$
declare remaining int;
begin
  update public.profiles set credits = credits + amount
  where id = uid returning credits into remaining;
  return remaining;
end $$;

revoke execute on function public.consume_credits(uuid, int) from public, anon, authenticated;
revoke execute on function public.refund_credits(uuid, int) from public, anon, authenticated;
grant execute on function public.consume_credits(uuid, int) to service_role;
grant execute on function public.refund_credits(uuid, int) to service_role;

-- Generated images ke liye storage bucket.
insert into storage.buckets (id, name, public) values ('images', 'images', true)
on conflict (id) do nothing;
