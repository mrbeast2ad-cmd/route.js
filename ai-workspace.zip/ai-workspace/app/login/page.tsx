'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase/client';

const appName = process.env.NEXT_PUBLIC_APP_NAME || 'AI Workspace';

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ tone: 'error' | 'info'; text: string } | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMessage(null);
    if (mode === 'signin') {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setMessage({ tone: 'error', text: error.message });
      else router.replace('/chat');
    } else {
      const { data, error } = await supabase.auth.signUp({ email, password });
      if (error) setMessage({ tone: 'error', text: error.message });
      else if (data.session) router.replace('/chat');
      else setMessage({ tone: 'info', text: 'Check your email and confirm your address, then sign in.' });
    }
    setBusy(false);
  }

  return (
    <main className="grid min-h-dvh lg:grid-cols-[1.1fr_1fr]">
      <section className="hidden flex-col justify-between bg-ink p-12 text-white lg:flex">
        <span className="text-lg font-semibold tracking-tight">{appName}</span>
        <div>
          <h1 className="max-w-md text-5xl font-bold leading-[1.05] tracking-tight">
            One prompt box for writing, code, summaries and images.
          </h1>
          <p className="mt-5 max-w-sm text-white/70">
            Pick a task, describe it, get the result. New accounts start with 20 free credits.
          </p>
        </div>
        <span className="text-sm text-white/50">Your conversations stay private to your account.</span>
      </section>

      <section className="flex items-center justify-center p-6">
        <form onSubmit={submit} className="w-full max-w-sm space-y-5">
          <h2 className="text-2xl font-bold">{mode === 'signin' ? 'Sign in' : 'Create your account'}</h2>

          <label className="block text-sm font-medium">
            Email
            <input
              type="email" required autoComplete="email" value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-ink/20 bg-white px-3.5 py-2.5 outline-none focus:border-lagoon"
            />
          </label>

          <label className="block text-sm font-medium">
            Password
            <input
              type="password" required minLength={8}
              autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
              value={password} onChange={(e) => setPassword(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-ink/20 bg-white px-3.5 py-2.5 outline-none focus:border-lagoon"
            />
            {mode === 'signup' && <span className="mt-1 block text-xs text-ink/60">At least 8 characters.</span>}
          </label>

          {message && (
            <p role="alert" className={`rounded-lg px-3 py-2 text-sm ${message.tone === 'error' ? 'bg-red-50 text-red-800' : 'bg-lagoon/10 text-lagoon-dark'}`}>
              {message.text}
            </p>
          )}

          <button
            disabled={busy}
            className="w-full rounded-lg bg-lagoon px-4 py-2.5 font-semibold text-white transition hover:bg-lagoon-dark disabled:opacity-60"
          >
            {busy ? 'Please wait…' : mode === 'signin' ? 'Sign in' : 'Create account'}
          </button>

          <button
            type="button"
            onClick={() => { setMode(mode === 'signin' ? 'signup' : 'signin'); setMessage(null); }}
            className="w-full text-center text-sm text-ink/70 underline-offset-4 hover:underline"
          >
            {mode === 'signin' ? 'No account yet? Create one' : 'Already have an account? Sign in'}
          </button>
        </form>
      </section>
    </main>
  );
}
