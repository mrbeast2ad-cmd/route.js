import type { Metadata, Viewport } from 'next';
import { Bricolage_Grotesque, Source_Serif_4 } from 'next/font/google';
import './globals.css';

const ui = Bricolage_Grotesque({ subsets: ['latin'], variable: '--font-ui' });
const reading = Source_Serif_4({ subsets: ['latin'], variable: '--font-reading' });

const appName = process.env.NEXT_PUBLIC_APP_NAME || 'AI Workspace';

export const metadata: Metadata = {
  title: appName,
  description: 'Write, code, summarise and create images with AI.',
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${ui.variable} ${reading.variable}`}>
      <body>{children}</body>
    </html>
  );
}
