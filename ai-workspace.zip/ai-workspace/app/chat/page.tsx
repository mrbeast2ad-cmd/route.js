'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase/client';
import { getCategory, type CategoryId } from '@/lib/categories';
import Sidebar, { type ConvoItem } from '@/components/Sidebar';
import CategorySelector from '@/components/CategorySelector';
import MessageBubble, { type Msg } from '@/components/MessageBubble';
import PromptInput from '@/components/PromptInput';

export default function ChatPage() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);
  const [credits, setCredits] = useState<number | null>(null);
  const [convos, setConvos] = useState<ConvoItem[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [category, setCategory] = useState<CategoryId>('writing');
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  const loadConvos = useCallback(async () => {
    const { data } = await supabase.from('conversations').select('id, title').order('created_at', { ascending: false });
    setConvos(data ?? []);
  }, []);

  const loadCredits = useCallback(async () => {
    const { data } = await supabase.from('profiles').select('credits').maybeSingle();
    if (data) setCredits(data.credits);
  }, []);

  // Login guard
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) router.replace('/login');
      else setSession(data.session);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      if (!s) router.replace('/login');
      else setSession(s);
    });
    return () => sub.subscription.unsubscribe();
  }, [router]);

  const userId = session?.user.id;
  useEffect(() => {
    if (userId) {
      loadConvos();
      loadCredits();
    }
  }, [userId, loadConvos, loadCredits]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, busy]);

  async function openConversation(id: string) {
    setMenuOpen(false);
    setError(null);
    setActiveId(id);
    const { data } = await supabase
      .from('messages')
      .select('id, role, kind, content')
      .eq('conversation_id', id)
      .order('created_at', { ascending: true });
    setMessages((data ?? []) as Msg[]);
  }

  function newChat() {
    setActiveId(null);
    setMessages([]);
    setError(null);
    setMenuOpen(false);
  }

  async function send() {
    const prompt = draft.trim();
    if (!prompt || busy) return;
    setBusy(true);
    setError(null);
    setDraft('');
    setMessages((m) => [...m, { id: crypto.randomUUID(), role: 'user', kind: 'text', content: prompt }]);
    try {
      const { data } = await supabase.auth.getSession();
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${data.session?.access_token}` },
        body: JSON.stringify({ conversationId: activeId, category, prompt }),
      });
      const out = await res.json();
      if (typeof out.credits === 'number') setCredits(out.credits);
      if (!res.ok) throw new Error(out.error ?? 'Something went wrong. Try again.');
      setMessages((m) => [...m, { id: out.messageId, role: 'assistant', kind: out.kind, content: out.reply }]);
      if (!activeId) {
        setActiveId(out.conversationId);
        loadConvos();
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong. Try again.');
      setDraft(prompt); // user ka likha hua wapas
      setMessages((m) => m.slice(0, -1));
    } finally {
      setBusy(false);
    }
  }

  async function signOut() {
    await supabase.auth.signOut();
    router.replace('/login');
  }

  if (!session) return <div className="grid h-dvh place-items-center text-ink/60">Loading…</div>;

  const cat = getCategory(category)!;

  return (
    <div className="flex h-dvh">
      <Sidebar
        conversations={convos}
        activeId={activeId}
        credits={credits}
        email={session.user.email ?? ''}
        open={menuOpen}
        onClose={() => setMenuOpen(false)}
        onNew={newChat}
        onSelect={openConversation}
        onSignOut={signOut}
      />

      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-3 border-b border-ink/10 px-4 py-3 lg:hidden">
          <button onClick={() => setMenuOpen(true)} className="rounded-lg border border-ink/20 px-3 py-1.5 text-sm" aria-label="Open menu">
            Menu
          </button>
          <span className="text-sm text-ink/60">{credits ?? '–'} credits</span>
        </header>

        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto w-full max-w-3xl space-y-6 px-4 py-8">
            {messages.length === 0 && !busy ? (
              <div className="pt-[8vh]">
                <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Pick a task, then describe it.</h1>
                <p className="mt-3 text-ink/70">Try one of these for {cat.label.toLowerCase()}:</p>
                <ul className="mt-4 space-y-2">
                  {cat.examples.map((ex) => (
                    <li key={ex}>
                      <button
                        onClick={() => setDraft(ex)}
                        className="w-full rounded-xl border border-ink/15 bg-white px-4 py-3 text-left text-sm transition hover:border-lagoon"
                      >
                        {ex}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              messages.map((m) => <MessageBubble key={m.id} m={m} />)
            )}

            {busy && (
              <div className="flex gap-1.5 py-2" role="status" aria-label="Working on your request">
                <span className="dot h-2 w-2 rounded-full bg-lagoon" />
                <span className="dot h-2 w-2 rounded-full bg-lagoon" />
                <span className="dot h-2 w-2 rounded-full bg-lagoon" />
              </div>
            )}
            <div ref={endRef} />
          </div>
        </div>

        <div className="border-t border-ink/10 bg-mist px-4 pb-4 pt-3">
          <div className="mx-auto w-full max-w-3xl space-y-3">
            {error && (
              <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-800">
                {error}
              </p>
            )}
            <CategorySelector value={category} onChange={setCategory} disabled={busy} />
            <PromptInput value={draft} onChange={setDraft} onSend={send} busy={busy} category={category} />
          </div>
        </div>
      </main>
    </div>
  );
}
