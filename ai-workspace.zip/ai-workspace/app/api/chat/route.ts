import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin as admin } from '@/lib/supabase/admin';
import { getCategory } from '@/lib/categories';
import { generateImage, generateText, type Turn } from '@/lib/ai';

export const runtime = 'nodejs';
export const maxDuration = 60; // image generation slow ho sakti hai

const MAX_PROMPT = 4000;
const HISTORY_TURNS = 10;

const fail = (status: number, error: string) => NextResponse.json({ error }, { status });

async function storeImage(userId: string, img: { b64?: string; url?: string }) {
  if (img.url) return img.url;
  const path = `${userId}/${crypto.randomUUID()}.png`;
  const { error } = await admin.storage
    .from('images')
    .upload(path, Buffer.from(img.b64!, 'base64'), { contentType: 'image/png' });
  if (error) throw error;
  return admin.storage.from('images').getPublicUrl(path).data.publicUrl;
}

export async function POST(req: NextRequest) {
  // 1. Auth: token verify karein
  const token = req.headers.get('authorization')?.replace(/^Bearer\s+/i, '');
  if (!token) return fail(401, 'Please sign in.');
  const { data: auth, error: authErr } = await admin.auth.getUser(token);
  if (authErr || !auth.user) return fail(401, 'Session expired. Please sign in again.');
  const user = auth.user;

  // 2. Input validate karein
  let body: { conversationId?: string | null; category?: string; prompt?: string };
  try {
    body = await req.json();
  } catch {
    return fail(400, 'Invalid request.');
  }
  const category = getCategory(body.category ?? '');
  const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
  if (!category) return fail(400, 'Unknown category.');
  if (!prompt) return fail(400, 'Write a prompt first.');
  if (prompt.length > MAX_PROMPT) return fail(400, `Prompt is too long (max ${MAX_PROMPT} characters).`);

  // 3. Purani conversation (agar hai) aur uski history
  let conversationId = body.conversationId ?? null;
  let history: Turn[] = [];
  if (conversationId) {
    const { data: convo } = await admin
      .from('conversations')
      .select('id')
      .eq('id', conversationId)
      .eq('user_id', user.id)
      .maybeSingle();
    if (!convo) return fail(404, 'Conversation not found.');
    const { data: rows } = await admin
      .from('messages')
      .select('role, content, kind')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: false })
      .limit(HISTORY_TURNS);
    history = (rows ?? [])
      .reverse()
      .filter((r) => r.kind === 'text')
      .map((r) => ({ role: r.role as Turn['role'], content: r.content }));
  }

  // 3b. Credits kaatein (atomic). Cost server decide karta hai.
  const { data: remaining, error: creditErr } = await admin.rpc('consume_credits', {
    uid: user.id,
    cost: category.cost,
  });
  if (creditErr) return fail(500, 'Could not check your credits.');
  if (remaining === null) return fail(402, `Not enough credits. ${category.label} needs ${category.cost}.`);

  // 4. AI call. Fail ho to credits wapas.
  let reply: string;
  try {
    if (category.kind === 'image') {
      reply = await storeImage(user.id, await generateImage(prompt));
    } else {
      reply = await generateText(category.system, history, prompt);
    }
  } catch (e) {
    console.error('AI call failed', e);
    const { data: refunded } = await admin.rpc('refund_credits', { uid: user.id, amount: category.cost });
    return NextResponse.json(
      { error: 'The AI service failed. Your credits were refunded. Try again.', credits: refunded },
      { status: 502 }
    );
  }

  // 5. Conversation + messages save karein
  let messageId: string = crypto.randomUUID();
  try {
    if (!conversationId) {
      const { data: created, error } = await admin
        .from('conversations')
        .insert({ user_id: user.id, title: prompt.slice(0, 60) })
        .select('id')
        .single();
      if (error) throw error;
      conversationId = created.id;
    }
    const now = Date.now();
    const kind = category.kind;
    const { data: saved, error } = await admin
      .from('messages')
      .insert([
        {
          conversation_id: conversationId,
          user_id: user.id,
          role: 'user',
          kind: 'text',
          category: category.id,
          content: prompt,
          created_at: new Date(now).toISOString(),
        },
        {
          conversation_id: conversationId,
          user_id: user.id,
          role: 'assistant',
          kind,
          category: category.id,
          content: reply,
          created_at: new Date(now + 1).toISOString(),
        },
      ])
      .select('id, role');
    if (error) throw error;
    messageId = saved?.find((m) => m.role === 'assistant')?.id ?? messageId;
  } catch (e) {
    // Reply mil chuka hai aur credits lag chuke hain, isliye user ko dikhate hain.
    console.error('Saving chat failed', e);
  }

  return NextResponse.json({
    conversationId,
    messageId,
    kind: category.kind,
    reply,
    credits: remaining,
  });
}
