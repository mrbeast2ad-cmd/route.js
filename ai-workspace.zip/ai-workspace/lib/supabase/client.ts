import { createClient } from '@supabase/supabase-js';

// Browser client: sirf anon key. RLS data ko protect karti hai.
export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);
