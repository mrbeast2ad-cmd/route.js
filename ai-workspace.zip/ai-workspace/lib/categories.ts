// Client aur server dono yahi file use karte hain.
// Cost server par is file se lagayi jati hai, client ke bheje hue number se nahi.

export type CategoryId = 'writing' | 'coding' | 'summary' | 'image';

export type Category = {
  id: CategoryId;
  label: string;
  cost: number;
  kind: 'text' | 'image';
  system: string;
  examples: string[];
};

export const CATEGORIES: Category[] = [
  {
    id: 'writing',
    label: 'Writing',
    cost: 1,
    kind: 'text',
    system:
      'You are a skilled writing assistant. Write clear, well-structured content in the language the user writes in. Ask no unnecessary questions; produce a good draft.',
    examples: [
      'Write a 150-word product description for a handmade leather wallet',
      'Draft a polite follow-up email to a client who has not paid an invoice',
    ],
  },
  {
    id: 'coding',
    label: 'Coding',
    cost: 2,
    kind: 'text',
    system:
      'You are a senior software engineer. Give correct, minimal, working code in fenced code blocks with a short explanation. Mention assumptions and edge cases briefly.',
    examples: [
      'Write a Python function that removes duplicate rows from a CSV by email column',
      'Explain why my React useEffect runs twice in development',
    ],
  },
  {
    id: 'summary',
    label: 'Summaries',
    cost: 1,
    kind: 'text',
    system:
      'You summarise text and data accurately. Lead with the key takeaway, then list the supporting points. Never invent facts that are not in the input.',
    examples: [
      'Summarise this meeting transcript into decisions and action items: ...',
      'Turn these survey results into five key findings: ...',
    ],
  },
  {
    id: 'image',
    label: 'Images',
    cost: 5,
    kind: 'image',
    system: '',
    examples: [
      'A lantern-lit courtyard at dusk, watercolour style',
      'Minimal flat logo of a mountain and a river, two colours',
    ],
  },
];

export const getCategory = (id: string) => CATEGORIES.find((c) => c.id === id);
