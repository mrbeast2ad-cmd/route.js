// SERVER ONLY. API keys yahan se bahar kabhi nahi jati.

export type Turn = { role: 'user' | 'assistant'; content: string };

async function readError(res: Response) {
  const text = await res.text().catch(() => '');
  return `${res.status} ${text.slice(0, 300)}`;
}

async function openaiText(system: string, history: Turn[], prompt: string) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: process.env.OPENAI_TEXT_MODEL || 'gpt-4o-mini',
      messages: [
        { role: 'system', content: system },
        ...history,
        { role: 'user', content: prompt },
      ],
    }),
  });
  if (!res.ok) throw new Error(`OpenAI: ${await readError(res)}`);
  const data = await res.json();
  return (data.choices?.[0]?.message?.content as string) ?? '';
}

async function geminiText(system: string, history: Turn[], prompt: string) {
  const model = process.env.GEMINI_MODEL || 'gemini-2.0-flash';
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': process.env.GEMINI_API_KEY || '',
      },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [
          ...history.map((t) => ({
            role: t.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: t.content }],
          })),
          { role: 'user', parts: [{ text: prompt }] },
        ],
      }),
    }
  );
  if (!res.ok) throw new Error(`Gemini: ${await readError(res)}`);
  const data = await res.json();
  const parts = data.candidates?.[0]?.content?.parts ?? [];
  return parts.map((p: { text?: string }) => p.text ?? '').join('');
}

export async function generateText(system: string, history: Turn[], prompt: string) {
  const text =
    process.env.TEXT_PROVIDER === 'gemini'
      ? await geminiText(system, history, prompt)
      : await openaiText(system, history, prompt);
  if (!text.trim()) throw new Error('Empty response from AI provider');
  return text;
}

export type GeneratedImage = { b64?: string; url?: string };

export async function generateImage(prompt: string): Promise<GeneratedImage> {
  const res = await fetch('https://api.openai.com/v1/images/generations', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: process.env.OPENAI_IMAGE_MODEL || 'gpt-image-1',
      prompt,
      size: '1024x1024',
      n: 1,
    }),
  });
  if (!res.ok) throw new Error(`OpenAI image: ${await readError(res)}`);
  const data = await res.json();
  const item = data.data?.[0];
  if (!item?.b64_json && !item?.url) throw new Error('No image returned');
  return { b64: item.b64_json, url: item.url };
}
