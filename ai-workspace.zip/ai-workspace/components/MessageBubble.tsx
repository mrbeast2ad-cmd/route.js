'use client';
import ReactMarkdown from 'react-markdown';

export type Msg = { id: string; role: 'user' | 'assistant'; kind: 'text' | 'image'; content: string };

export default function MessageBubble({ m }: { m: Msg }) {
  if (m.role === 'user') {
    return (
      <div className="flex justify-end">
        <p className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-br-md bg-ink px-4 py-2.5 text-white">
          {m.content}
        </p>
      </div>
    );
  }

  if (m.kind === 'image') {
    return (
      <figure className="max-w-md">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={m.content} alt="Generated image" className="w-full rounded-xl border border-ink/10" />
        <figcaption className="mt-2 text-sm">
          <a href={m.content} target="_blank" rel="noreferrer" className="text-lagoon underline underline-offset-4">
            Open full size
          </a>
        </figcaption>
      </figure>
    );
  }

  return (
    <div className="md max-w-[48rem] font-reading">
      <ReactMarkdown>{m.content}</ReactMarkdown>
    </div>
  );
}
