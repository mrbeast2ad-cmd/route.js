'use client';
import { CATEGORIES, type CategoryId } from '@/lib/categories';

type Props = { value: CategoryId; onChange: (id: CategoryId) => void; disabled?: boolean };

export default function CategorySelector({ value, onChange, disabled }: Props) {
  return (
    <div role="radiogroup" aria-label="Task type" className="flex gap-2 overflow-x-auto pb-1">
      {CATEGORIES.map((c) => {
        const selected = c.id === value;
        return (
          <button
            key={c.id}
            role="radio"
            aria-checked={selected}
            disabled={disabled}
            onClick={() => onChange(c.id)}
            className={`shrink-0 rounded-full border px-4 py-1.5 text-sm font-medium transition disabled:opacity-60 ${
              selected ? 'border-lagoon bg-lagoon text-white' : 'border-ink/20 bg-white text-ink hover:border-lagoon'
            }`}
          >
            {c.label}
            <span className={`ml-2 text-xs ${selected ? 'text-white/80' : 'text-ink/50'}`}>
              {c.cost} {c.cost === 1 ? 'credit' : 'credits'}
            </span>
          </button>
        );
      })}
    </div>
  );
}
