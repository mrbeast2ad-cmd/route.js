'use client';
import { getCategory, type CategoryId } from '@/lib/categories';

type Props = {
  value: string;
  onChange: (v: string) => void;
  onSend: () => void;
  busy: boolean;
  category: CategoryId;
};

export default function PromptInput({ value, onChange, onSend, busy, category }: Props) {
  const cat = getCategory(category)!;
  const placeholder = cat.kind === 'image' ? 'Describe the image you want…' : 'Describe what you need…';

  return (
    <div className="flex items-end gap-2 rounded-2xl border border-ink/20 bg-white p-2 focus-within:border-lagoon">
      <textarea
        value={value}
        rows={1}
        maxLength={4000}
        placeholder={placeholder}
        aria-label="Prompt"
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
            e.preventDefault();
            onSend();
          }
        }}
        className="max-h-48 min-h-[44px] flex-1 resize-none bg-transparent px-3 py-2.5 outline-none"
        style={{ fieldSizing: 'content' } as React.CSSProperties}
      />
      <button
        onClick={onSend}
        disabled={busy || !value.trim()}
        className="rounded-xl bg-lagoon px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-lagoon-dark disabled:cursor-not-allowed disabled:opacity-50"
      >
        {busy ? 'Working…' : `Send · ${cat.cost}`}
      </button>
    </div>
  );
}
