'use client';

export type ConvoItem = { id: string; title: string };

type Props = {
  conversations: ConvoItem[];
  activeId: string | null;
  credits: number | null;
  email: string;
  open: boolean;
  onClose: () => void;
  onNew: () => void;
  onSelect: (id: string) => void;
  onSignOut: () => void;
};

const appName = process.env.NEXT_PUBLIC_APP_NAME || 'AI Workspace';

export default function Sidebar({ conversations, activeId, credits, email, open, onClose, onNew, onSelect, onSignOut }: Props) {
  return (
    <>
      {open && <div className="fixed inset-0 z-30 bg-black/40 lg:hidden" onClick={onClose} aria-hidden />}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-72 flex-col bg-ink text-white transition-transform lg:static lg:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
        aria-label="Conversations"
      >
        <div className="flex items-center justify-between px-5 pb-3 pt-5">
          <span className="text-lg font-semibold tracking-tight">{appName}</span>
          <button onClick={onClose} className="rounded p-1 text-white/70 lg:hidden" aria-label="Close menu">✕</button>
        </div>

        <div className="px-4 pb-3">
          <button
            onClick={onNew}
            className="w-full rounded-lg bg-lagoon px-3 py-2.5 text-left text-sm font-semibold transition hover:bg-lagoon-dark"
          >
            New chat
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-2 pb-2">
          {conversations.length === 0 ? (
            <p className="px-3 py-4 text-sm text-white/50">Your conversations will appear here.</p>
          ) : (
            <ul className="space-y-0.5">
              {conversations.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => onSelect(c.id)}
                    aria-current={c.id === activeId ? 'page' : undefined}
                    className={`block w-full truncate rounded-lg px-3 py-2 text-left text-sm transition ${
                      c.id === activeId ? 'bg-white/12 text-white' : 'text-white/75 hover:bg-white/8'
                    }`}
                  >
                    {c.title}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </nav>

        <div className="space-y-3 border-t border-white/10 p-4">
          <div className="rounded-lg bg-ink-soft px-3 py-2.5">
            <div className="text-2xl font-bold text-amber-300">{credits ?? '–'}</div>
            <div className="text-xs text-white/60">credits left</div>
          </div>
          <div className="flex items-center justify-between gap-2 text-xs text-white/60">
            <span className="truncate">{email}</span>
            <button onClick={onSignOut} className="shrink-0 underline underline-offset-4 hover:text-white">Sign out</button>
          </div>
        </div>
      </aside>
    </>
  );
}
